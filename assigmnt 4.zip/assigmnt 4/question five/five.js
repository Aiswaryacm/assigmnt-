
function validate(){
    var output="";
    for( var x=0;x<=15;x++){
        if(x==0){
           output=x+ "is even" + "<br>";
        }
        else if (x%2==0){
        output+=x+ "is even" + "<br>";}
        else 
        output+=x+"is odd" + "<br>";

    }
document.write(output)

}