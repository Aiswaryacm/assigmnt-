var myarr = [];

 
function addTo() {
   myarr.push(document.getElementById("userinput").value);
   document.getElementById("userinput").value=null;
   console.log(myarr); //to confirm it has been added to the array
   
 
}
function sortarray(){
    myarr.sort();
    document.write("sorted array is" + myarr)
}