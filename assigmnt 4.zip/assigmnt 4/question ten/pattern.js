let pattern=document.getElementById("pattern");
var i,j;
function getPattern(){
for(i=1;i<=4;i++){
    for(j=1;j<=i;j++){
 document.write("*")
    }
document.write("<br/>")
}
}
