function validate()
{
var a=10;
var b=25;
var larger=findLarge(a,b);
document.write(larger)

}
function findLarge(a,b){
    if(a>b){
        return a;}
        else return b;
        
}