let java=document.getElementById("java");
function validate(){
const iterable = 'javascript';
var addon="";
for (const value of iterable) {
    
    addon=addon+value 
    document.write(addon) 
    document.write("<br/>")
}}