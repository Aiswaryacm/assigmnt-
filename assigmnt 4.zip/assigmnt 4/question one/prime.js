let array=document.getElementById("array");
function validate(){
var numbers = ["11", "2", "3", "4", "5", "6", "7", "8", "9", "10"];

var text = "";
var i;
var number;
var isPrimeValue="";
document.getElementById("prime").innerHTML = numbers;
number = numbers[0]*1;
if(isPrime(number))
  {
    isPrimeValue="Prime"
  }
  else
  {
    isPrimeValue="Not Prime"
  }
 
 text += "The number " + number + " is " + isPrimeValue + "<br>";
 
document.getElementById("array").innerHTML = text;

}
 
function isPrime(number) {
    var start = 2;
    while (start <= Math.sqrt(number)) {
        if (number % start++ < 1) return false;
    }
    return number > 1;
    
}
