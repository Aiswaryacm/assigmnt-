
var originalstr="The Quick Brown Fox";
var uppercase="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var lowercase="abcdefghijklmnopqrstuvwxyz";
var output=[];
function validate(){
for(var x=0;x<originalstr.length;x++)
{
    if(uppercase.indexOf(originalstr[x])!==-1)
    {
     output=output+(originalstr[x].toLowerCase());
    }
    else if(lowercase.indexOf(originalstr[x])!==-1)
    {
        output=output+(originalstr[x].toUpperCase());
    }
    else
    {
        output=output+(originalstr[x]);
    }
}
document.write(output)
}