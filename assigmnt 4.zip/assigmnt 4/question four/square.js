var sumsqs = [];
    var sumsq = Number(prompt("Please enter a number to calculate the sum the square or -1 to stop"));
    while (sumsq != -1) {
    sumsqs.push(sumsq);
      sumsq = Number(prompt("Please enter a number to calculate the sum the square or -1 to stop"));
    }

    var total_sumsqs = 0;
    for (var index = 0; index < sumsqs.length; index++) {
    total_sumsqs = total_sumsqs + sumsqs[index] * sumsqs[index];
    }

    document.write("<h3>The sum of squares is " + total_sumsqs + ".</h3>");