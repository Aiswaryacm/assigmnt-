var arr1 = [40, 't', 't', 't', 40, 4, 't', 7, 'i', 8, 40, 40, 40];
var mf = 1;
var m = 0;
var item;
function validate(){
for (var i = 0; i < arr1.length; i++) {
  for (var j = i; j < arr1.length; j++) {
    if (arr1[i] == arr1[j]) m++;
    if (mf < m) {
      mf = m;
      item = arr1[i];
    }
  }

  m = 0;
}

alert(item + " ( " + mf + " times ) "); }