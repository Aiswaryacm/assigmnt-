var myarr = [];
var x;


function addTo() {
    myarr.push(document.getElementById("userinput").value);
    document.getElementById("userinput").value = null;
    document.getElementById("userinput").focus();
    // console.log(myarr); //to confirm it has been added to the array


}
function sortarray() {
    document.getElementById("array").innerHTML = "the given array is: ";
    for (x in myarr) {
        document.getElementById("array").innerHTML += myarr[x] + ",";

    }
    myarr.sort();

    document.getElementById("sortedarray").innerHTML = "the sorted array is: " + myarr;
}